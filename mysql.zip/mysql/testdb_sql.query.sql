use testdb;

select * from st_info;
select NAME, DEPI from st_info;
select NAME, DEPI from st_info where DEPI = 'Game';

select Linux from st_grade where ST_ID=202201;
select DB from st_grade where ST_ID=202201;
select Linux, DB from st_grade where ST_ID=202201;

select st_info.NAME, st_info.DEPI, st_grade.Linux, st_grade.DB
from st_info, st_grade
where st_info.ST_ID=202201 and st_grade.ST_ID=202201;

update st_info set DEPI='Computer' where ST_ID=202201;

select st_info.NAME, st_info.DEPI, st_grade.Linux, st_grade.DB
from st_info, st_grade
where st_info.ST_ID=202201 and st_grade.ST_ID=202201;

update st_grade set DB=90 where ST_ID=202201;

select st_info.NAME, st_info.DEPI, st_grade.Linux, st_grade.DB
from st_info, st_grade
where st_info.ST_ID=202201 and st_grade.ST_ID=202201;